import os

if __name__ == '__main__':

    os.system('py images.py')
    os.system('py api.py')
    os.system('py application.py')
    